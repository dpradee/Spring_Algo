# Shopping Cart Application V1.0 

[ Base URL: localhost:8080/catalog ]
 http://localhost:8080/catalog/v2/api-docs

## About

This is a demo project for practicing Spring + Thymeleaf. The idea was to build some basic shopping cart web app.

It was made using Spring Boot,SwaggerUi,Spring Data REST,Lombok,Maven,Mockito.
for data store used map and collections as per suggestions given in mail.
In this application basically two controllers are there.
UserControler-->  to create,update,delete and fetch the users related data.
ShoppingCartController--> Users can shop for products. Each user has his own shopping cart .
Note--> two product detaisl as id (1 ,2)has been stored in map when any user trying to addproducttoCart he should pass product id as "1" or "2" only because its hard codes data.


## How to run

You can run the application from the command line with Maven. 
Or you can build a single executable JAR file that contains all the necessary dependencies, classes, and resources, and run that.
Go to the root folder of the application and type:
```
./mvnw spring-boot:run
```
Or you can build the JAR file with 
```
./mvnw clean package
``` 
Then you can run the JAR file:
```
java -jar target/ShoppingCart-0.0.1-SNAPSHOT.jar
```
The application should be up and running within a few seconds.

Go to the web browser and visit `http://localhost:8080/catalog/swagger-ui.html#/` you will get swaggerUI Page 
which will work like client from there you  can all rest apis which developed on microservices architechture



In `/src/main/resources/application.properties` file it is possible to change change the port number as well as context path.,
as well as change the port number.

## Helper Tools
PostMan also used for checking the apis details 
### Mockito Testing#####

I have been used the mockito testing framework to test my apis functionality.


