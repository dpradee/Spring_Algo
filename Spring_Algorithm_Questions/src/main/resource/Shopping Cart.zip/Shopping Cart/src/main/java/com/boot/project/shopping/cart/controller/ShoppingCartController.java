package com.boot.project.shopping.cart.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.boot.project.shopping.cart.exception.NotEnoughProductsInStockException;
import com.boot.project.shopping.cart.model.ShoppingCartDetails;
import com.boot.project.shopping.cart.service.IProductService;
import com.boot.project.shopping.cart.service.IShoppingCartService;

@RestController
@RequestMapping(value = "/rest/shoppingcart")
public class ShoppingCartController {
	private static final Logger log = LoggerFactory.getLogger(ShoppingCartController.class);

	@Autowired
	IShoppingCartService shoppingcartService;

	@Autowired
	private IProductService productService;

	@GetMapping("/shoppingCart")
	public ResponseEntity<ShoppingCartDetails> shoppingCart() {
		ShoppingCartDetails shoppingDetails = new ShoppingCartDetails();
		shoppingDetails.setProducts(
				shoppingcartService.getProductsInCart() != null ? shoppingcartService.getProductsInCart() : null);
		shoppingDetails.setTotal(shoppingcartService.getTotal() != null ? shoppingcartService.getTotal() : null);

		return new ResponseEntity<>(shoppingDetails, HttpStatus.OK);

	}

	@PostMapping(value = "/shoppingCart/addProduct/{productId}")
	public ResponseEntity<ShoppingCartDetails> addProductToCart(@PathVariable("productId") Long productId) {
		shoppingcartService.addProduct(productService.findById(productId));
		return shoppingCart();
	}

	@PostMapping(value = "/shoppingCart/removeProduct/{productId}")
	public ResponseEntity<ShoppingCartDetails> removeProductFromCart(@PathVariable("productId") Long productId) {
		shoppingcartService.removeProduct(productService.findById(productId));
		return shoppingCart();
	}

	@GetMapping(value = "/shoppingCart/checkout")
	public ResponseEntity<ShoppingCartDetails> checkout() throws NotEnoughProductsInStockException {
		try {
			shoppingcartService.checkout();
		} catch (NotEnoughProductsInStockException e) {
			log.error(e.getMessage());
			throw e;
		}
		return shoppingCart();
	}
}
