package com.boot.project.shopping.cart.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.boot.project.shopping.cart.dto.UserDetailsDto;
import com.boot.project.shopping.cart.request.CreateUserReq;
import com.boot.project.shopping.cart.service.IUserService;

/**
 * Created by pradeep on 18-May-20.
 */
@RestController
@RequestMapping("/rest/user")
public class UserController {

	@Autowired
	private IUserService userService;

	@PostMapping("/create")
	public ResponseEntity<String> create(@RequestBody CreateUserReq req) {
		try {
			if(userService.fetchUserByEmail(req.getEmailId())!=null) {
				return new ResponseEntity<>("user already exist with this emailId", HttpStatus.OK);
			}
			else if(userService.fetchUserById(req.getEmailId())!=null) {
				return new ResponseEntity<>("user already exist with this userId", HttpStatus.OK);
			}else {
			userService.createUser(req);
			}
			return new ResponseEntity<>("user created successfully", HttpStatus.OK);

		} catch (Exception e) {
		}
		return null;
	}

	@PutMapping("/update")
	public ResponseEntity<String> update(@RequestBody CreateUserReq updateReq) {
		if(userService.fetchUserByEmail(updateReq.getEmailId())!=null) {
			return new ResponseEntity<>("user already exist with this emailId", HttpStatus.OK);
		}
		else if(userService.fetchUserById(updateReq.getEmailId())!=null) {
			return new ResponseEntity<>("user already exist with this userId", HttpStatus.OK);
		}
		else {
		userService.updateUser(updateReq);
		return new ResponseEntity<>("user updated successfully", HttpStatus.OK);
		}
	}

	@GetMapping("/fetch/{id}")
	public ResponseEntity<UserDetailsDto> fetchById(@PathVariable("id") String userId) {
		UserDetailsDto resp = userService.fetchUserById(userId);
		return new ResponseEntity<>(resp, HttpStatus.OK);

	}

	@DeleteMapping("/delete/{id}")
	public ResponseEntity<String> delete(@PathVariable("id") String userId) {
		userService.deleteUser(userId);
		return new ResponseEntity<>("user deleted successfully", HttpStatus.OK);

	}

}
