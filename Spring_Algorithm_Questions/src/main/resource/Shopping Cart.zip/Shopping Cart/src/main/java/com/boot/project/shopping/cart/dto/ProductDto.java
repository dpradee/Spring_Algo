package com.boot.project.shopping.cart.dto;

import java.math.BigDecimal;

import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Min;

import org.hibernate.validator.constraints.Length;

import lombok.Data;
import lombok.EqualsAndHashCode;
@Data
@EqualsAndHashCode
public class ProductDto {
	 private Long id;
	    @Length(min = 3, message = "*Name must have at least 5 characters")
	    private String name;
	    private String description;
	    @Min(value = 0, message = "*Quantity has to be non negative number")
	    private Integer quantity;
	    @DecimalMin(value = "0.00", message = "*Price has to be non negative number")
	    private BigDecimal price;

	

}
