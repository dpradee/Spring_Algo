package com.boot.project.shopping.cart.dto;

public class ShoppingCart {

}
