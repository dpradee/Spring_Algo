package com.boot.project.shopping.cart.dto;

import lombok.Data;

@Data
public class UserDetailsDto {
	private String userId;
	private String firstName;
	private String lastName;
	private String emailId;
	private String desc;
}
