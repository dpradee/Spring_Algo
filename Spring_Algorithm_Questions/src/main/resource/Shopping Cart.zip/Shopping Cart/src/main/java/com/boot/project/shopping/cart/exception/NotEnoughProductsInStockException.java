package com.boot.project.shopping.cart.exception;

import com.boot.project.shopping.cart.dto.ProductDto;


/**
 * Created by pradeep on 18 may 2020.
 */
public class NotEnoughProductsInStockException extends Exception {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
    private static final String DEFAULT_MESSAGE = "Not enough products in stock";

    public NotEnoughProductsInStockException() {
        super(DEFAULT_MESSAGE);
    }

    public NotEnoughProductsInStockException(ProductDto product) {
        super("Not enough " + product.getName() + " products in stock. Only " + product.getQuantity() + " left");

        
    }

}
