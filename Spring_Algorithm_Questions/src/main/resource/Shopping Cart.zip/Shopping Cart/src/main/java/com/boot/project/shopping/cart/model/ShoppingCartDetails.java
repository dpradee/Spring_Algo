package com.boot.project.shopping.cart.model;

import java.math.BigDecimal;
import java.util.Map;

import com.boot.project.shopping.cart.dto.ProductDto;

import lombok.Data;

@Data
public class ShoppingCartDetails {
	private BigDecimal total;
	private Map<ProductDto, Integer> products;
}
