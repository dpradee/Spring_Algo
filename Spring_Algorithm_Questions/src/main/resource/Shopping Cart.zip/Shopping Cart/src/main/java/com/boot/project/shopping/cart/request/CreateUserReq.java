package com.boot.project.shopping.cart.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;

@JsonIgnoreProperties
@Data
public class CreateUserReq {
	   private String userId;
	    private String firstName;
	    private String lastName;
		private String emailId;
		private String desc;
	}

