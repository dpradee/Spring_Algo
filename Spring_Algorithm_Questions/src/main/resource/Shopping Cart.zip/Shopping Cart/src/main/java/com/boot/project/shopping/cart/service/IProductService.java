package com.boot.project.shopping.cart.service;

import java.util.Collection;
import java.util.List;

import com.boot.project.shopping.cart.dto.ProductDto;

/**
 * Created by pradeep on 18-May-20.
 */
public interface IProductService {

    ProductDto findById(Long id);
    List<ProductDto> findAllProducts();
    void save(Collection<ProductDto> products);

}
