/**
 * 
 */
package com.boot.project.shopping.cart.service;

import java.math.BigDecimal;
import java.util.Map;

import com.boot.project.shopping.cart.dto.ProductDto;
import com.boot.project.shopping.cart.exception.NotEnoughProductsInStockException;


/**
 * @author M1046717
 *
 */
public interface IShoppingCartService {
	void addProduct(ProductDto product);

    void removeProduct(ProductDto product);

    Map<ProductDto, Integer> getProductsInCart();

    void checkout() throws NotEnoughProductsInStockException;

    BigDecimal getTotal();
}
