package com.boot.project.shopping.cart.service;

import com.boot.project.shopping.cart.dto.UserDetailsDto;
import com.boot.project.shopping.cart.request.CreateUserReq;

public interface IUserService {
void createUser(CreateUserReq user);
void updateUser(CreateUserReq user);
UserDetailsDto fetchUserById(String userId);
UserDetailsDto fetchUserByEmail(String email);
void deleteUser(String userId);
}
