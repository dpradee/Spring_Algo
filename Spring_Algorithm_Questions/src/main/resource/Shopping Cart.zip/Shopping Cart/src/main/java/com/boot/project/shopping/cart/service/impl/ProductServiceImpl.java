package com.boot.project.shopping.cart.service.impl;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.springframework.stereotype.Service;

import com.boot.project.shopping.cart.dto.ProductDto;
import com.boot.project.shopping.cart.service.IProductService;

/**
 * Created by pradeep on 18-May-2020.
 */
@Service
public class ProductServiceImpl implements IProductService {

	List<ProductDto> productList=new ArrayList<>();

    @Override
    public List<ProductDto> findAllProducts() {
    	return getprojectList();
    	
    }

    private List<ProductDto> getprojectList() {
    	ProductDto product1= new ProductDto();
    	product1.setId(1L);
    	product1.setName("prod1");
    	product1.setPrice(new BigDecimal("100.50"));
    	product1.setDescription("desc");
    	product1.setQuantity(2);
    	productList.add(product1);
    	ProductDto product2= new ProductDto();
    	product2.setId(2L);
    	product2.setName("prod2");
    	product2.setPrice(new BigDecimal("200.50"));
    	product2.setDescription("desc1");
    	product2.setQuantity(3);
    	productList.add(product2);
		// TODO Auto-generated method stub
		return productList;
		
	}

	@Override
    public ProductDto findById(Long id) {
		if(productList.size()==0) {
       getprojectList();
        }
		return productList.stream().filter(ls->ls.getId()==id).findFirst().orElse(null);
		  
    }

	@Override
	public void save(Collection<ProductDto> products) {
		// TODO Auto-generated method stub
		productList.clear();
		productList.addAll(products);
	}
}
