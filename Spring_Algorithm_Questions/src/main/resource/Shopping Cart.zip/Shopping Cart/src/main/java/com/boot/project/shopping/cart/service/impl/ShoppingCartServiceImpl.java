package com.boot.project.shopping.cart.service.impl;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Service;
import org.springframework.web.context.WebApplicationContext;

import com.boot.project.shopping.cart.dto.ProductDto;
import com.boot.project.shopping.cart.exception.NotEnoughProductsInStockException;
import com.boot.project.shopping.cart.service.IProductService;
import com.boot.project.shopping.cart.service.IShoppingCartService;



/**
 * Shopping Cart is implemented with a Map, and as a session bean
 *
 * @author Dusan
 */
@Service
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)

public class ShoppingCartServiceImpl implements IShoppingCartService {

	 @Autowired
	 IProductService productservice;

	    private Map<ProductDto, Integer> products = new HashMap<>();

	    /**
	     * If product is in the map just increment quantity by 1.
	     * If product is not in the map with, add it with quantity 1
	     *
	     * @param product
	     */
	    @Override
	    public void addProduct(ProductDto product) {
	        if (products.containsKey(product)) {
	            products.replace(product, products.get(product) + 1);
	        } else {
	            products.put(product, 1);
	        }
	    }

	    /**
	     * If product is in the map with quantity > 1, just decrement quantity by 1.
	     * If product is in the map with quantity 1, remove it from map
	     *
	     * @param product
	     */
	    @Override
	    public void removeProduct(ProductDto product) {
	        if (products.containsKey(product)) {
	            if (products.get(product) > 1)
	                products.replace(product, products.get(product) - 1);
	            else if (products.get(product) == 1) {
	                products.remove(product);
	            }
	        }
	    }

	    /**
	     * @return unmodifiable copy of the map
	     */
	    @Override
	    public Map<ProductDto, Integer> getProductsInCart() {
	        return Collections.unmodifiableMap(products);
	    }

	    /**
	     * Checkout will rollback if there is not enough of some product in stock
	     *
	     * @throws NotEnoughProductsInStockException
	     */
	    @Override
	    public void checkout() throws NotEnoughProductsInStockException {
	    	ProductDto product;
	        for (Map.Entry<ProductDto, Integer> entry : products.entrySet()) {
	            // Refresh quantity for every product before checking
	            product = productservice.findById(entry.getKey().getId());
	            if (product.getQuantity() < entry.getValue())
	                throw new NotEnoughProductsInStockException(product);
	            entry.getKey().setQuantity(product.getQuantity() - entry.getValue());
	        }
	        productservice.save(products.keySet());
	       
	        products.clear();
	    }

	    @Override
	    public BigDecimal getTotal() {
	        BigDecimal total = BigDecimal.ZERO;
	        for (Map.Entry<ProductDto, Integer> entry : products.entrySet()) {
	            total = total.add(entry.getKey().getPrice().multiply(new BigDecimal(entry.getValue())));
	        }
	        return total;
	    }
}
