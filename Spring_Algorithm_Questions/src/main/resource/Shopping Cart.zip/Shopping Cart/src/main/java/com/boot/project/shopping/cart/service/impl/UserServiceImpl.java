package com.boot.project.shopping.cart.service.impl;

import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.boot.project.shopping.cart.dto.UserDetailsDto;
import com.boot.project.shopping.cart.request.CreateUserReq;
import com.boot.project.shopping.cart.service.IUserService;
@Service
public class UserServiceImpl implements IUserService {
Map<String,CreateUserReq>usersMap=new HashMap<>() ;
	@Override
	public void createUser(CreateUserReq user) {
		if(user!=null) {
			if(!usersMap.containsKey(user.getUserId())){
				usersMap.put(user.getUserId(),user);
			}
		}
		
		
	}

	@Override
	public void updateUser(CreateUserReq user) {
		if(user!=null) {
			if(usersMap.containsKey(user.getUserId())){
				CreateUserReq update = usersMap.get(user.getUserId());
				update.setFirstName(user.getFirstName());
				update.setLastName(user.getLastName());
				update.setEmailId((user.getEmailId()));
				update.setDesc(user.getDesc());
			}
		}
		
	}

	@Override
	public UserDetailsDto fetchUserById(String userId) {
		if(usersMap.containsKey(userId)){
			CreateUserReq update = usersMap.get(userId);
			UserDetailsDto respDto=new UserDetailsDto();
			respDto.setFirstName(update.getFirstName());
			respDto.setLastName(update.getLastName());
			respDto.setEmailId((update.getEmailId()));
			respDto.setDesc(update.getDesc());
			respDto.setUserId(update.getUserId());
			return respDto;
		}
		return null;
	}

	@Override
	public void deleteUser(String userId) {
		if(usersMap.containsKey(userId)){
			usersMap.remove(userId);
		}
		
	}

	@SuppressWarnings("unlikely-arg-type")
	@Override
	public UserDetailsDto fetchUserByEmail(String email) {
		UserDetailsDto respDto = null;
		CreateUserReq update = null;
		Map<String, CreateUserReq> emailMap = usersMap.entrySet().stream().filter(map -> email.equals(map.getValue()))
				.collect(Collectors.toMap(map -> map.getKey(), map -> map.getValue()));
		if (emailMap != null && emailMap.entrySet().size()!=0) {
			update = emailMap.entrySet().iterator().next().getValue();
			if (update != null) {
				respDto = new UserDetailsDto();
				respDto.setFirstName(update.getFirstName());
				respDto.setLastName(update.getLastName());
				respDto.setEmailId((update.getEmailId()));
				respDto.setDesc(update.getDesc());
				respDto.setUserId(update.getUserId());
				return respDto;
			}

		}
		return null;
	}

}
