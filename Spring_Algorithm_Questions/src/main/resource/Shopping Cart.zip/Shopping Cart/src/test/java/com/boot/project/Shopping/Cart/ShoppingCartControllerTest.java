package com.boot.project.Shopping.Cart;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.boot.project.shopping.cart.controller.ShoppingCartController;
import com.boot.project.shopping.cart.dto.ProductDto;
import com.boot.project.shopping.cart.exception.NotEnoughProductsInStockException;
import com.boot.project.shopping.cart.model.ShoppingCartDetails;
import com.boot.project.shopping.cart.service.impl.ShoppingCartServiceImpl;

@RunWith(MockitoJUnitRunner.class)
public class ShoppingCartControllerTest {

	@Mock
	ShoppingCartServiceImpl serviceMock;
	@InjectMocks
	ShoppingCartController shoppingCartController;

	@Test
	public void testshoppingCart() {

		when(serviceMock.getProductsInCart()).thenReturn(getproducts());
		assertEquals("product1", shoppingCartController.shoppingCart().getBody().getProducts().entrySet().iterator()
				.next().getKey().getName());
	}

	private Map<ProductDto, Integer> getproducts() {
		Map<ProductDto, Integer> products = new HashMap<>();
		ProductDto dtos = new ProductDto();
		dtos.setId(1L);
		dtos.setName("product1");
		products.put(dtos, 1);
		return products;
	}

	@Test
	public void testaddProductToCart() {
		ProductDto dtos = new ProductDto();
		dtos.setId(1L);
		dtos.setName("product1");
		doNothing().when(serviceMock).addProduct(dtos);
		serviceMock.addProduct(dtos);
		verify(serviceMock, times(1)).addProduct(dtos);
		ShoppingCartController spyControler = Mockito.spy(shoppingCartController);
		ResponseEntity<ShoppingCartDetails> accept = new ResponseEntity<>(new ShoppingCartDetails(), HttpStatus.OK);
		Mockito.doReturn(accept).when(spyControler).shoppingCart();
		ResponseEntity<ShoppingCartDetails> status = spyControler.shoppingCart();

		assertEquals(accept, status);

	}

	@Test
	public void testremoveProductToCart() {
		ProductDto dtos = new ProductDto();
		dtos.setId(1L);
		dtos.setName("product1");
		doNothing().when(serviceMock).removeProduct(dtos);
		;
		serviceMock.removeProduct(dtos);
		verify(serviceMock, times(1)).removeProduct(dtos);
		ShoppingCartController spyControler = Mockito.spy(shoppingCartController);
		ResponseEntity<ShoppingCartDetails> accept = new ResponseEntity<>(new ShoppingCartDetails(), HttpStatus.OK);
		Mockito.doReturn(accept).when(spyControler).shoppingCart();
		ResponseEntity<ShoppingCartDetails> status = spyControler.shoppingCart();

		assertEquals(accept, status);

	}

	@Test
	public void testCheckOut() throws NotEnoughProductsInStockException {
		ProductDto dtos = new ProductDto();
		dtos.setId(1L);
		dtos.setName("product1");
		doNothing().when(serviceMock).checkout();
		serviceMock.checkout();
		verify(serviceMock, times(1)).checkout();
		ShoppingCartController spyControler = Mockito.spy(shoppingCartController);
		ResponseEntity<ShoppingCartDetails> accept = new ResponseEntity<>(new ShoppingCartDetails(), HttpStatus.OK);
		Mockito.doReturn(accept).when(spyControler).shoppingCart();
		ResponseEntity<ShoppingCartDetails> status = spyControler.shoppingCart();

		assertEquals(accept, status);

	}
}
