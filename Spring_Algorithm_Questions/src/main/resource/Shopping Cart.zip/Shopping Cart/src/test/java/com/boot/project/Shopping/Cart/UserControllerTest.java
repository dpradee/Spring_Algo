package com.boot.project.Shopping.Cart;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.boot.project.shopping.cart.controller.UserController;
import com.boot.project.shopping.cart.dto.UserDetailsDto;
import com.boot.project.shopping.cart.request.CreateUserReq;
import com.boot.project.shopping.cart.service.impl.UserServiceImpl;

@RunWith(MockitoJUnitRunner.class)
public class UserControllerTest {
	@Mock
	UserServiceImpl userServiceMock;

	@InjectMocks
	UserController userController;

	@Test
	public void testfetchUserById() {

		when(userServiceMock.fetchUserById("pradeep123")).thenReturn(getuserDetails());
		assertEquals("pradeep", userController.fetchById("pradeep123").getBody().getFirstName());
	}

	private UserDetailsDto getuserDetails() {
		UserDetailsDto dtos = new UserDetailsDto();
		dtos.setUserId("pradeep123");
		dtos.setFirstName("pradeep");
		return dtos;
	}

	@Test
	public void testdeleteUser() {
		doNothing().when(userServiceMock).deleteUser("123");
		userServiceMock.deleteUser("123");
		verify(userServiceMock, times(1)).deleteUser("123");

	}

	@Test
	public void testcreateUser() {
		CreateUserReq req = new CreateUserReq();
		req.setUserId("123");
		doNothing().when(userServiceMock).createUser(req);
		userServiceMock.createUser(req);
		verify(userServiceMock, times(1)).createUser(req);

	}

	@Test
	public void testUpdateUser() {
		CreateUserReq req = new CreateUserReq();
		req.setUserId("123");
		doNothing().when(userServiceMock).updateUser(req);
		userServiceMock.updateUser(req);
		verify(userServiceMock, times(1)).updateUser(req);

	}

}
